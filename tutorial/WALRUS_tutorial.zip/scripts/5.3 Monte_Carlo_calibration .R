
#################
# Getting started 
#################

# Remove everything from R's memory.
rm(list=ls())

# Load the WALRUS package.
library(WALRUS)

# Change working directory to the folder where data-, figures- and output-subfolders 
# are located.
setwd("D:/Dropbox/WALRUS_cursus/")


######
# Data
######

# Read daily or hourly precipitation, potential evapotranspiration and discharge data.
data = read.table("data/PEQ_Hupsel_hour.dat", header=TRUE)

# Specify which period of the total data set you want to use as forcing data.
# Use the same date format as in data file (for example yyyymmddhh).
forc = WALRUS_selectdates("data", 2011120000, 2012020000)

# Preprocessing forcing and specifying for which moments output should be stored. 
# The argument dt is time step size used in the output data file (in hours).
WALRUS_preprocessing(f=forc, dt=1)


#####################
# Change Q-h-relation
#####################

# Build a function in which the discharge is computed as a function of stage height.
func_Q_hS_Hupsel = function(x, pars, hSmin)
{
  h = x/1000
  if(h <= 0)
  {
    0
  }else if(h < 0.2)
  {
    (10 ^(0.1645 + 2.0144 * log10(h) + 0.1342 * log10(h)^2)) *0.5538
  }else if(h <= 1.5)
  {
    (10 ^ (0.2741 + 2.3236 * log10(h) + 0.3511 * log10(h)^2)) *0.5538
  }else{
    2.769 + (10 ^(0.2741 + 2.3236 * log10(h-1.5) + 0.3511 * log10(h-1.5)^2)) *0.5538
  }
}

# Then set this function as the current stage-discharge relation.
set_func_Q_hS(func_Q_hS_Hupsel)


##########################
# Monte Carlo calibration
##########################

# # Make many (in this example 10000) random parameter sets within certain limits.
# cW = runif(10000, min=100, max=400 )
# cV = runif(10000, min=0.1, max=50  )
# cG = runif(10000, min=1e5, max=1e8 )
# cQ = runif(10000, min=1  , max=100 )
# 
# # Make an empty vector to store mean sums of squares during for-loop.
# SS = c()
# 
# # Run a for-loop over all parameter sets and run WALRUS in every iteration.
# for(i in 1:10000)
# {
#   # look up the parameter set for this iteration
#   parameters = data.frame(cW=cW[i], cV=cV[i], cG=cG[i], cQ=cQ[i], 
#                           dG0=1300, cD=1500, aS=0.01, st="loamy_sand")
#   
#   # run WALRUS
#   modeled    = WALRUS_loop(pars=parameters)
#   
#   # Compute and store the mean sum of squares.
#   SS[i]      = mean((Qobs_forNS-modeled$Q)^2)    
# }
# 
# # Write the results to file: parameter values and belonging sum of squares.
# write.table(data.frame(cbind(cW, cV, cG, cQ, SS)), "output/pars_SS_MC_Hupsel.dat")


##############################
# Read output from Monte Carlo
##############################

# read output from Monte Carlo run
MC = read.table("output/pars_SS_MC_Hupsel.dat", header=TRUE)

# dotty plots: plot one parameter on the x-axis and goodness of fit on the y-axis
plot(MC$cW, MC$SS, col="purple")
plot(MC$cV, MC$SS, col="red")
plot(MC$cG, MC$SS, col="orange")
plot(MC$cQ, MC$SS, col="forestgreen")

# select best 0.1%
best_pars = MC[MC$SS < quantile(MC$SS,0.001),]

# write best parameter sets to file
write.table(best_pars, "best_pars_MC_Hupsel.dat", row.names=FALSE)


###############################
# Parameters and initial values
###############################

# make empty vector for modelled discharge
Qmod = matrix(ncol=10, nrow=nrow(forc)+1)

for(i in 1:10)
  {
  print(i)
  
  # Define the parameters (cW, cV, cG, cQ, cS), initial conditions (dG0) and 
  # catchment characteristics (cD, aS, soil type).
  pars = data.frame(cW=best_pars$cW[i], cV=best_pars$cV[i], 
                    cG=best_pars$cG[i]* 1e6, cQ=best_pars$cQ[i], 
                    dG0=1300, cD=1500, aS=0.01, st="loamy_sand")
  
  
  #####
  # Run
  #####
  
  # Run the model. 
  mod = WALRUS_loop(pars=pars)
  
  # save modelled Q in the matrix
  Qmod[,i] = mod$Q
  }


######
# Plot
######

# plot observed discharge
plot(c(0,forc$Q), type="l")

# plot lines for eack parameter set
for(i in 1:10)
  {
  lines(Qmod[,i], col="dodgerblue")
  }

# draw observed discharge on top
lines(c(0,forc$Q))













