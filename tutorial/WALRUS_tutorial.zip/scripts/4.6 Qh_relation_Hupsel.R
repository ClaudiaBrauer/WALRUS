
#################
# Getting started 
#################

# Remove everything from R's memory.
rm(list=ls())

# Load the WALRUS package.
library(WALRUS)

# Change working directory to the folder where data-, figures- and output-subfolders 
# are located.
setwd("D:/Dropbox/WALRUS_cursus/")


######
# Data
######

# Read daily or hourly precipitation, potential evapotranspiration and discharge data.
data = read.table("data/PEQ_Hupsel_hour.dat", header=TRUE)

# Specify which period of the total data set you want to use as forcing data.
# Use the same date format as in data file (for example yyyymmddhh).
forc = WALRUS_selectdates("data", 2011120000, 2012020000)

# Preprocessing forcing and specifying for which moments output should be stored. 
# The argument dt is time step size used in the output data file (in hours).
WALRUS_preprocessing(f=forc, dt=1)


#####################
# Change Q-h-relation
#####################

# Build a function in which the discharge is computed as a function of stage height.
# The arguments pars and hSmin are included even though they are not used in the function.
func_Q_hS_Hupsel = function(x, pars, hSmin)
{
  h = x/1000
  if(h <= 0)
  {
    0
  }else if(h < 0.2)
  {
    (10 ^(0.1645 + 2.0144 * log10(h) + 0.1342 * log10(h)^2)) *0.5538
  }else if(h <= 1.5)
  {
    (10 ^ (0.2741 + 2.3236 * log10(h) + 0.3511 * log10(h)^2)) *0.5538
  }else{
    2.769 + (10 ^(0.2741 + 2.3236 * log10(h-1.5) + 0.3511 * log10(h-1.5)^2)) *0.5538
  }
}

# Then set this function as the current stage-discharge relation.
set_func_Q_hS(func_Q_hS_Hupsel)

# And to check if you did it right:
show_func_Q_hS()

# To check the value for a specific stage height manually:
func_Q_hS_Hupsel(x=1000)


###############################
# Parameters and initial values
###############################

# Define the parameters (cW, cV, cG, cQ, cS), initial conditions (dG0) and 
# catchment characteristics (cD, aS, soil type).
pars = data.frame(cW=200, cV=4, cG=5e6, cQ=10, cS=4,  
                  dG0=1250, cD=1500, aS=0.01, st="loamy_sand")

#####
# Run
#####

# Run the model. 
mod = WALRUS_loop(pars=pars)


##########################
# Output files and figures
##########################

# Give the run a logical name. This will be used for the output data files and figures.
name = "Qh_relation_Hupsel"

# Postprocessing: create datafiles and show figures.
WALRUS_postprocessing(o=mod, pars=pars, n=name)


#######################
# Compare Q-h-relations
#######################

# Set back to original function
set_func_Q_hS(NULL)
func_Q_hS_default = show_func_Q_hS()

# Rewrite functions for plotting.
func_Q_hS_Hupsel_for_plot  = Vectorize(function(x){return(func_Q_hS_Hupsel(x))})
func_Q_hS_default_for_plot = Vectorize(function(x){return(func_Q_hS_default(x,pars=pars,hSmin=0))})

# Plot two curves and add a legend.
curve(func_Q_hS_default_for_plot, col="dodgerblue", 0, 1600, ylim=c(0,4), xlab="h [mm]", ylab="Q [mm/h]")
curve(func_Q_hS_Hupsel_for_plot, col="purple", add=TRUE)
legend(c("Default","Hupsel"),col=c("dodgerblue","purple"), lty=1, bty="n", x="topleft")


