
#################
# Getting started 
#################

# Remove everything from R's memory.
rm(list=ls())

# Load the WALRUS package.
library(WALRUS)

# Change working directory to the folder where data-, figures- and output-subfolders 
# are located.
setwd("D:/Dropbox/WALRUS_cursus/")


######
# Data
######

# Read daily or hourly precipitation, potential evapotranspiration and discharge data.
data = read.table("data/PEQ_Cabauw_hour.dat", header=TRUE)

# Specify which period of the total data set you want to use as forcing data.
# Use the same date format as in data file (for example yyyymmddhh).
forc = WALRUS_selectdates("data", 2007100000, 2008100000)

# Preprocessing forcing and specifying for which moments output should be stored. 
# The argument dt is time step size used in the output data file (in hours).
WALRUS_preprocessing(f=forc, dt=1)



#####################
# Change Q-h-relation
#####################

# Build a function in which the discharge is computed as a function of stage height.
func_Q_hS_Cabauw = function(x, pars, hSmin)
{
  h = (x - hSmin) /1000
  if(h <= 0)
  {
    0
  }else if(h<0.0307)
  {
    (2.247*h^2+0.0391*h-0.00006) *7.2
  }else{
    (-0.4176*h^3+1.409*h^2+0.089*h-0.0008) *7.2
  }
}

# Then set this function as the current stage-discharge relation.
set_func_Q_hS(func_Q_hS_Cabauw)


###############################
# Parameters and initial values
###############################

# Define the parameters (cW, cV, cG, cQ, cS), initial conditions (dG0) and 
# catchment characteristics (cD, aS, soil type).
pars = data.frame(cW=110, cV=14, cG=118e6, cQ=76, 
                  dG0=246, cD=1500, aS=0.05, st="cal_C")


#####
# Run
#####

# Run the model. 
mod = WALRUS_loop(pars=pars)


##########################
# Output files and figures
##########################

# Give the run a logical name. This will be used for the output data files and figures.
name = "summer_winter_Cabauw"

# Postprocessing: create datafiles and show figures.
WALRUS_postprocessing(o=mod, pars=pars, n=name)

