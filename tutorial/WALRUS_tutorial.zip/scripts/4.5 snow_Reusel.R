
#################
# Getting started 
#################

# Remove everything from R's memory.
rm(list=ls())

# Load the WALRUS package.
library(WALRUS)

# Change working directory to the folder where data-, figures- and output-subfolders 
# are located.
setwd("D:/Dropbox/WALRUS_cursus/")


######
# Data
######

# Read daily or hourly precipitation, potential evapotranspiration and discharge data.
data = read.table("data/PEQ_Reusel_Hondsberg_hour.dat", header=TRUE)

# Specify which period of the total data set you want to use as forcing data.
# Use the same date format as in data file (for example yyyymmddhh).
forc = WALRUS_selectdates("data", 2009121200, 2010012000)

# Preprocessing forcing and specifying for which moments output should be stored. 
# The argument dt is time step size used in the output data file (in hours).
WALRUS_preprocessing(f=forc, dt=1)



###############################
# Parameters and initial values
###############################

# Define the parameters (cW, cV, cG, cQ, cS), initial conditions (dG0) and 
# catchment characteristics (cD, aS, soil type).
pars = data.frame(cW=249, cV=70, cG=56e6, cQ=72, cS=5, 
                  dG0=900, cD=1500, aS=0.01, st="loamy_sand")


#####
# Run
#####

# Run the model. 
mod = WALRUS_loop(pars=pars)


##########################
# Output files and figures
##########################

# Give the run a logical name. This will be used for the output data files and figures.
name = "snow_Reusel_no_correction"

# Postprocessing: create datafiles and show figures.
WALRUS_postprocessing(o=mod, pars=pars, n=name)


###################
# Snow module - DHF
###################

# Run the snow module.
# Choices for methods: "DHF" (degreehour factor), "SRF" (shortwave radiation factor)
# and "EB" (energy balance - not implemented yet)
forc_DHF = WALRUS_snow(forc, method="DHF")

# Preprocessing forcing and specifying for which moments output should be stored. 
# The argument dt is time step size used in the output data file (in hours).
WALRUS_preprocessing(f=forc_DHF, dt=1)

# Run the model. 
mod_DHF = WALRUS_loop(pars=pars)

# Give the run a logical name. This will be used for the output data files and figures.
name = "snow_Reusel_DHF"

# Postprocessing: create datafiles and show figures.
WALRUS_postprocessing(o=mod_DHF, pars=pars, n=name)


###################
# Snow module - SRF
###################

# Run the snow module.
# Choices for methods: "DHF" (degreehour factor), "SRF" (shortwave radiation factor)
# and "EB" (energy balance - not implemented yet)
forc_SRF = WALRUS_snow(forc, method="SRF")

# Preprocessing forcing and specifying for which moments output should be stored. 
# The argument dt is time step size used in the output data file (in hours).
WALRUS_preprocessing(f=forc_SRF, dt=1)

# Run the model. 
mod_SRF = WALRUS_loop(pars=pars)

# Give the run a logical name. This will be used for the output data files and figures.
name = "snow_Reusel_SRF"

# Postprocessing: create datafiles and show figures.
WALRUS_postprocessing(o=mod_SRF, pars=pars, n=name)


######
# Plot
######

# plot Q
par(mfrow=c(2,1))
plot(mod$Q, col="dodgerblue", type="l", ylim=c(0,0.25), xaxt="n", xlab="", ylab="Q")
lines(mod_DHF$Q, col="forestgreen")
lines(mod_SRF$Q, col="red")
lines(c(0,forc$Q), col="black")

# add legend
legend(c("obs","no snow","DHF","SRF"), col=c("black","dodgerblue","forestgreen","red"), 
       x="topleft", bty="n", lty=1)

# plot T and P
plot(forc$T, col="orange", type="l", xaxt="n", xlab="", ylab="T and P")
abline(h=0)
lines(forc$P, col="purple", type="h")

# add legend
legend(c("T","P"), col=c("orange","purple"), x="topleft", bty="n", lty=1)


