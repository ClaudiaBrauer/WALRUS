

#################
# Getting started 
#################

# Remove everything from R's memory.
rm(list=ls())

# Load the shiny and WALRUS packages.
library(shiny) # in case of error: did you install the necessary packages?
library(WALRUS)

# Change working directory to the folder where data-, figures- and output-subfolders 
# are located. It should end with .../WALRUS_cursus"
loc = "D:/Dropbox/WALRUS/WALRUS_tutorial"


###################
# Run the shiny app
###################

# Run the Shiny app.
runApp(paste(loc,"/shiny", sep=""))

# Running WALRUS in Shiny sometimes takes a little while.


#################
# Troubleshooting
#################

# If the app doesn't run in a window in RStudio, click "open in browser".

# Preferred browsers are Firefox or Chrome.
# To set the browser, uncomment one of the following lines:
# options(browser = "C:/Program Files (x86)/Mozilla Firefox/firefox.exe")
# options(browser = "C:/Program Files/Mozilla Firefox/firefox.exe")

# You can also run a portable version of Firefox.
# Download the .exe from this site: 
# http://portableapps.com/apps/internet/firefox_portable
# Save it in the folder WALRUS_cursus and install it. 
# Then run the following command.
# options(browser = paste(loc, "/FirefoxPortable/FirefoxPortable.exe",sep=""))

# To force RStudio to run the App in the browser, click the arrow in the top right corner of 
# this screen (in newer versions of RStudio) and select "Run external" or uncomment this line:
# options(shiny.launch.browser=TRUE)

