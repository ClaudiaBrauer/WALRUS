##   This is a shiny script to run
##   the Wageningen Lowland Runoff Simulator (WALRUS): 
##   a lumped rainfall-runoff model for catchments with shallow groundwater
##   WALRUS is licensed under the GPL v3 license.

################################
# RUN ONCE WHEN APP IS LAUNCHED
################################

# load packages
library(shiny)
library(WALRUS)

#####################################
# RUN EACH TIME WHEN USER VISITS APP
#####################################
shinyServer(function(input, output) {
  
  ########################################
  # RUN EACH TIME A USER CHANGES A WIDGET
  ########################################
  
  output$result <- renderPlot({
  
  # read daily or hourly discharge, precipitation and potential evapotranspiration data
  PEQ_data <<- read.table(paste(loc,"/data/PEQ_Hupsel_hour.dat", sep=""), header=TRUE)
  
  # specify which period of the total data set you want to use as forcing data
  forc = WALRUS_selectdates("PEQ_data", input$startdate*100, input$enddate*100)
  
  # preprocessing forcing and output data file
  WALRUS_preprocessing(f=forc, dt=1)
    
  # parameters and initial values
  pars = data.frame(cW=input$cW, cV=input$cV, cG=input$cG*1e6, cQ=input$cQ, cS=input$cS,
                    cD=input$cD, dG0=input$dG0, aS=input$aS, st=input$st)
  
  # run the model
  mod = WALRUS_loop(pars=pars)
  
  # plot output    
  WALRUS_shiny_figures(o=mod, pars=pars)
  
  }, height=800, width=800)
})


