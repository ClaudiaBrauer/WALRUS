library(shiny)

# Define UI for application that draws a histogram
shinyUI(fluidPage(

  # Application title
  titlePanel("WALRUS"),

  # Sidebar with a slider input for the number of bins
  sidebarLayout(
    sidebarPanel(
      h5("Forcing"),
      selectInput("site", label = "Catchment", 
                  choices = list("Hupselse Beek (Jan 2005 - May 2014)"="Hupsel", 
                                 "Cabauw (Jun 2007 - Aug 2010)"="Cabauw",
                                 "Bakelse Aa (Apr 2010 - Mrt 2011)"="BakelseAa",
                                 "Reusel (Jan 2000 - May 2013)"="Reusel_Hondsberg",
                                 "Berkel (Jan 2010 - Dec 2010)"="Berkel_Stadtlohn",
                                 "Lunterse Beek (Jan 2011 - Sep 2013)"="Luntersebeek"), 
                  selected = 1),
      numericInput("startdate", label="Start date", value=20111200),
      numericInput("enddate"  , label="End date"  , value=20120200),
      hr(),
      h5("Parameters and inital conditions"),
      sliderInput("cW", "cW, constant for wetness index [mm]", min=1, max=400, value=200),
      sliderInput("cV", "cV, vadose zone relaxation time [h]", min=0.1, max=50, value=4),
      sliderInput("cG", "cG, groundwater reservoir constant [x 1,000,000 mm h]", min=1, max=100, value=5),
      sliderInput("cQ", "cQ, quickflow reservoir constant [h]", min=1, max=100, value=10),
      sliderInput("cS", "cS, bankfull discharge [mm/h]", min=0.1, max=10, value=4),
      sliderInput("dG0", "dG0, initial groundwater depth [mm]", min=1, max=3000, value=1250),
      hr(),
      h5("Catchment characteristics"),
      sliderInput("cD", "cD, channel depth [mm]", min=1, max=3000, value=1500),
      sliderInput("aS", "aS, surface water area fraction [-]", min=0, max=0.1, value=0.01),
      selectInput("st", label = "Soil type", 
                  choices = list("sand"="sand", "loamy sand"="loamy_sand", "sandy loam"="sandy_loam", 
                    "silt loam"="silt_loam", "loam"="loam", "sandy clay loam"="sandy_clay_loam", 
                    "silt clay loam"="silt_clay_loam", "clay loam"="clay_loam", 
                    "sandy clay"="sandy_clay", "silty clay"="silty_clay", "clay"="clay", 
                    "Hupsel"="cal_H", "Cabauw"="cal_C"), 
                  selected = "loamy_sand")),       


    # Show a plot of the generated distribution
    mainPanel(plotOutput("result"))
  )
))

